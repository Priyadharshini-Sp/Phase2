/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pro;

import java.util.List;
import javax.persistence.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

/**
 *
 * @author spriy
 */
public class TeaAsubDAO {
     public int insert(AddST c) {
		SessionFactory sf=Config.hibConfig();
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		int r=(int)s.save(c);
                t.commit();
		return r;
	}
     public List<AddST> get() {
		SessionFactory sf=Config.hibConfig();
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		Query q=s.createQuery("from AddST");
		List<AddST> cl =q.getResultList();
		t.commit();
		return cl;
	}
      public void delete(AddST c){
        SessionFactory sf=Config.hibConfig();
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
                Query q=s.createQuery("delete from Student where id=:id");
                s.delete(c);
                t.commit();
                
    }
      public List<AddST> retrieve(){
          SessionFactory sf=Config.hibConfig();
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		Query q=s.createQuery("from AddST where classname=:classname");
                List<AddST> cl =q.getResultList();
		t.commit();
		return cl;
          
      }

   
}
