/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pro;

import java.util.List;
import javax.persistence.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

/**
 *
 * @author spriy
 */
public class StudentDAO {
    public List<Student> get() {
		SessionFactory sf=Config.hibConfig();
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		Query q=s.createQuery("from Student");
		List<Student> cl =q.getResultList();
		t.commit();
		return cl;
	}

    public int insert(Student c) {
		SessionFactory sf=Config.hibConfig();
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		int r=(int)s.save(c);
                t.commit();
		return r;
	}
    public void delete(Student c){
        SessionFactory sf=Config.hibConfig();
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
                Query q=s.createQuery("delete from Student where id=:id");
                s.delete(c);
                t.commit();
                
    }
    public int update(Student c){
        SessionFactory sf=Config.hibConfig();
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
                Query q=s.createQuery("update Student set Firstname=:Firstname,Lastname=:Lastname,DOB=:DOB,Address=:Address,Phone=:Phone,classname=:classname where id=:id");
                q.setParameter("id",c.getId());
                q.setParameter("Firstname", c.getFirstname());
                q.setParameter("Lastname", c.getLastname());
                q.setParameter("DOB", c.getDOB());
                q.setParameter("Address", c.getAddress());
                q.setParameter("Phone", c.getPhone());
                q.setParameter("classname", c.getClassname());
                int r=q.executeUpdate();
                t.commit();
                 return r;
        
    }
}
