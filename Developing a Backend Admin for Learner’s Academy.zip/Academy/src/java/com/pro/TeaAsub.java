/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pro;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author spriy
 */
@Entity
public class TeaAsub {
    @Id
    private int id;
    @Column
     private String subject;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getTeachername() {
        return Teachername;
    }

    public void setTeachername(String Teachername) {
        this.Teachername = Teachername;
    }
            @Column
    private String Teachername;
    
}
