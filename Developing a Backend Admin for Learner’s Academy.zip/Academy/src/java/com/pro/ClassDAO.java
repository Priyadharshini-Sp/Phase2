/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pro;

import java.util.List;
import javax.persistence.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

/**
 *
 * @author spriy
 */
public class ClassDAO {
     public int insert(newclass c) {
		SessionFactory sf=Config.hibConfig();
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		int r=(int)s.save(c);
                t.commit();
		return r;
	}
    public List<newclass> get() {
		SessionFactory sf=Config.hibConfig();
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		Query q=s.createQuery("from newclass");
		List<newclass> cl =q.getResultList();
		t.commit();
		return cl;
	}
    public int update(newclass c){
        SessionFactory sf=Config.hibConfig();
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
                Query q=s.createQuery("update newclass set classname=:classname where id=:id");
                q.setParameter("id",c.getId());
                q.setParameter("classname", c.getClassname());
                int r=q.executeUpdate();
                t.commit();
                 return r;
        
    }
    public void delete(newclass c){
        SessionFactory sf=Config.hibConfig();
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
                Query q=s.createQuery("delete from newclass where id=:id");
                s.delete(c);
                t.commit();
                
    }
    

    
    
}
