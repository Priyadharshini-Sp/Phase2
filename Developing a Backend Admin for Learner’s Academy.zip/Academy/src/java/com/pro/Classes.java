/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pro;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author spriy
 */
@Entity
public class Classes {
    @Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
@Column
	private String classname;

    public int getId() {
        return id;
    }

    public void setId(int cid) {
        this.id = id;
    }

    

    public String getClassname() {
        return classname;
    }

    public void setClassname(String classname) {
        this.classname = classname;
    }
    
}
